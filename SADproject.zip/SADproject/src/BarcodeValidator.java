import java.util.Set;

public class BarcodeValidator {
    private static final Set<String> validBrands = Set.of("MHV", "DXN", "DNV", "VCS", "ILG", "OFA", "GWF", "CVF", "KIG", "QJO", "GRV", "MUX", "GIE", "KJT", "WUT");
    private static final Set<String> validManufacturers = Set.of("IF", "TJ", "PL", "KI", "BW", "RG");

    public static boolean isBarcodeValid(String barcode) {
        if (barcode.length() != 18) return false;
//        if (!validManufacturers.contains(barcode.substring(0, 2))) return false;
//        if (!validBrands.contains(barcode.substring(2, 5))) return false;
//
//        for (int i = 0; i < 5; ++i)
//            if (!Character.isLetter(barcode.charAt(i))) return false;
//        for (int i = 5; i < 18; ++i)
//            if (!Character.isDigit(barcode.charAt(i))) return false;

        return true;
    }
}
