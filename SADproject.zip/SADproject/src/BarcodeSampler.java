import java.util.Random;
import java.util.List;

public class BarcodeSampler {
    private Random random;

    public BarcodeSampler() {
        this.random = new Random();
    }

    public String getRandomBarcode(List<String> barcodes) {
        int index = random.nextInt(barcodes.size());
        return barcodes.get(index);
    }
}
