import java.util.ArrayList;
import java.util.List;

public class BarcodeProcessor {
    private BarcodeSampler sampler;

    public BarcodeProcessor(BarcodeSampler sampler) {
        this.sampler = sampler;
    }

    public List<String> sampleAndCheckBarcodes(int numberOfSamples, List<String> barcodes) {
        List<String> invalidBarcodes = new ArrayList<>();
        
        for (int i = 0; i < numberOfSamples; ++i) {
            String selectedBarcode = sampler.getRandomBarcode(barcodes);
            System.out.println("Sampled Barcode: " + selectedBarcode);
            if (!BarcodeValidator.isBarcodeValid(selectedBarcode)) {
                System.out.println("Error: Invalid barcode.");
                invalidBarcodes.add(selectedBarcode);
            }
        }
        
        return invalidBarcodes;
    }

    public List<String> randomSampling(double riskPercent, List<String> barcodes) {
        List<String> sampledBarcodes = new ArrayList<>();
        int sampleSize;

        if (riskPercent >= 0.03) {
            sampleSize = 15;
        } else if (riskPercent >= 0.02) {
            sampleSize = 10;
        } else {
            sampleSize = 5;
        }

        for (int i = 0; i < sampleSize; ++i) {
            String selectedBarcode = sampler.getRandomBarcode(barcodes);
            System.out.println("Second Sampling: " + selectedBarcode);
            sampledBarcodes.add(selectedBarcode);
        }

        return sampledBarcodes;
    }
}
